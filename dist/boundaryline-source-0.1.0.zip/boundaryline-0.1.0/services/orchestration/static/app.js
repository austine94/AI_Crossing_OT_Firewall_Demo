const elements = {
  selector: document.querySelector("#scenario-selector"),
  registryMeta: document.querySelector("#registry-meta"),
  runState: document.querySelector("#run-state"),
  runId: document.querySelector("#run-id"),
  scenarioTitle: document.querySelector("#scenario-title"),
  scenarioBadge: document.querySelector("#scenario-badge"),
  scenarioSummary: document.querySelector("#scenario-summary"),
  preflight: document.querySelector("#preflight"),
  inventoryList: document.querySelector("#inventory-list"),
  resetAction: document.querySelector("#reset-action"),
  autonomousAction: document.querySelector("#autonomous-action"),
  probeAction: document.querySelector("#probe-action"),
  exportAction: document.querySelector("#export-action"),
  controlNote: document.querySelector("#control-note"),
  outcome: document.querySelector("#outcome-banner"),
  decisionNetwork: document.querySelector("#decision-network"),
  decisionBroker: document.querySelector("#decision-broker"),
  decisionPolicy: document.querySelector("#decision-policy"),
  decisionResource: document.querySelector("#decision-resource"),
  decisionAsset: document.querySelector("#decision-asset"),
  edgeDirect: document.querySelector("#edge-direct"),
  edgeDirectLabel: document.querySelector("#edge-direct-label"),
  edgeBroker: document.querySelector("#edge-broker"),
  agentNodeTitle: document.querySelector("#agent-node-title"),
  agentNodeState: document.querySelector("#agent-node-state"),
  inventoryNode: document.querySelector("#inventory-node"),
  brokerNode: document.querySelector("#broker-node"),
  policyNode: document.querySelector("#policy-node"),
  policyNodeTitle: document.querySelector("#policy-node-title"),
  policyNodeState: document.querySelector("#policy-node-state"),
  inspectionKicker: document.querySelector("#inspection-kicker"),
  inspectionTitle: document.querySelector("#inspection-title"),
  toolContent: document.querySelector("#tool-content"),
  eventCount: document.querySelector("#event-count"),
  timeline: document.querySelector("#timeline-content"),
  dialog: document.querySelector("#event-dialog"),
  dialogTitle: document.querySelector("#dialog-title"),
  dialogJson: document.querySelector("#dialog-json"),
  dialogClose: document.querySelector("#dialog-close"),
  toast: document.querySelector("#toast"),
};

const uiHeaders = { Accept: "application/json", "X-BoundaryLine-UI": "dashboard-v1" };
let registry = null;
let currentEvents = [];
let preflightReady = false;
let stateTimer = null;
let eventSocket = null;

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("is-visible");
  window.setTimeout(() => elements.toast.classList.remove("is-visible"), 3200);
}

function displayScenario(scenario) {
  elements.scenarioTitle.textContent = `${scenario.scenario} — ${scenario.label}`;
  elements.scenarioSummary.textContent = scenario.summary;
  elements.scenarioBadge.textContent = scenario.readiness.replace("_", " ").toUpperCase();
  elements.scenarioBadge.dataset.state = scenario.readiness;
  const firewallMode = scenario.scenario === "A";
  const policyEnabled = scenario.scenario === "C";
  elements.policyNode.classList.toggle("is-muted", !(policyEnabled || firewallMode));
  elements.policyNodeTitle.textContent = firewallMode ? "Network policy" : "Policy engine";
  elements.agentNodeTitle.textContent = firewallMode ? "Fixed firewall probe" : "Patch agent";
  elements.agentNodeState.textContent = firewallMode ? "controlled adapter" : "monitoring-reader";
  elements.inventoryNode.classList.toggle("is-hidden", firewallMode);
  elements.brokerNode.classList.toggle("is-hidden", firewallMode);
  elements.edgeBroker.classList.toggle("is-hidden", firewallMode);
  elements.edgeDirectLabel.textContent = firewallMode ? "fixed request" : "direct probe";
  elements.policyNodeState.textContent = policyEnabled
    ? "enforced before OT access"
    : firewallMode
      ? "nftables rules inspected"
      : "not evaluated in this mode";
  elements.inspectionKicker.textContent = firewallMode ? "RULE INSPECTOR" : "LATEST TOOL CALL";
  elements.inspectionTitle.textContent = firewallMode ? "Observed nftables rules" : "Proposal and identity";
  if (!currentEvents.length) {
    if (firewallMode) renderFirewallRules(null, null);
    else renderToolEvidence(null, null);
  }
}

function applyControlState() {
  if (!registry) return;
  const running = ["starting", "active"].includes(registry.run_state);
  const finished = ["completed", "failed"].includes(registry.run_state);
  const selected = registry.scenarios.find((item) => item.scenario === registry.selected_scenario);
  const capabilities = new Set(selected?.capabilities || []);
  elements.probeAction.disabled = !(preflightReady && capabilities.has("deterministic_probe") && registry.run_state === "idle" && !registry.current_run_id);
  elements.resetAction.disabled = !finished;
  elements.exportAction.disabled = !(finished && currentEvents.length > 0);
  elements.autonomousAction.disabled = !(preflightReady && capabilities.has("autonomous_run") && registry.run_state === "idle" && !registry.current_run_id);
  elements.controlNote.textContent = running
    ? "Run in progress. Scenario switching and reset are locked."
    : finished
      ? "Inspect or export the immutable evidence, then reset before another run."
      : capabilities.has("autonomous_run")
        ? "Choose a live autonomous model run or the reproducible controlled test."
        : registry.selected_scenario === "A"
          ? "Run the controlled test to compare the permissive and corrected firewall rules."
          : "Run the controlled test to replay the same out-of-scope request under policy enforcement.";
}

function renderRegistry(data) {
  registry = data;
  elements.registryMeta.textContent = `Manifest ${data.manifest_version} · ${data.manifest_hash.slice(0, 18)}…`;
  elements.runState.textContent = data.run_state;
  elements.runId.textContent = data.current_run_id || "Not started";
  elements.selector.replaceChildren();

  data.scenarios.forEach((scenario) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "scenario-card";
    button.disabled = scenario.readiness !== "ready" || ["starting", "active"].includes(data.run_state);
    button.setAttribute("aria-pressed", String(scenario.scenario === data.selected_scenario));
    button.title = scenario.readiness_reason;
    button.innerHTML = `
      <span class="scenario-letter">${scenario.scenario}</span>
      <span class="scenario-name">${scenario.short_label}</span>
      <span class="scenario-readiness">${scenario.readiness.replace("_", " ")}</span>
    `;
    button.addEventListener("click", () => selectScenario(scenario.scenario));
    elements.selector.append(button);
  });

  const selected = data.scenarios.find((item) => item.scenario === data.selected_scenario);
  displayScenario(selected);
  applyControlState();
}

async function loadPreflight(scenarioId) {
  elements.preflight.className = "preflight";
  elements.preflight.innerHTML = '<span class="spinner" aria-hidden="true"></span> Checking fixed service dependencies…';
  try {
    const response = await fetch(`/v1/scenarios/${scenarioId}/preflight`, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`Preflight returned ${response.status}`);
    const result = await response.json();
    const readyCount = result.checks.filter((check) => check.ready).length;
    preflightReady = result.ready;
    elements.preflight.classList.add(result.ready ? "is-ready" : "is-failed");
    elements.preflight.textContent = result.ready
      ? `READY · ${readyCount}/${result.checks.length} required services healthy`
      : `NOT READY · ${readyCount}/${result.checks.length} checks passed`;
  } catch (error) {
    preflightReady = false;
    elements.preflight.classList.add("is-failed");
    elements.preflight.textContent = "PREFLIGHT UNAVAILABLE · orchestration API did not respond";
  }
  applyControlState();
}

async function loadInventory() {
  try {
    const response = await fetch("/v1/dashboard/inventory", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`Inventory returned ${response.status}`);
    const assets = await response.json();
    elements.inventoryList.replaceChildren();
    assets.forEach((asset) => {
      const row = document.createElement("div");
      const id = document.createElement("code");
      id.textContent = asset.asset_id;
      const status = document.createElement("span");
      status.textContent = asset.patch_status;
      row.append(id, status);
      elements.inventoryList.append(row);
    });
  } catch (error) {
    elements.inventoryList.textContent = "Trusted inventory unavailable";
  }
}

async function selectScenario(scenarioId) {
  try {
    const response = await fetch(`/v1/scenarios/${scenarioId}/select`, { method: "POST", headers: uiHeaders });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || `Selection returned ${response.status}`);
    await loadRegistry({ refreshPreflight: true });
    showToast(`Scenario ${scenarioId} selected. Fixed preflight passed.`);
  } catch (error) {
    showToast(error.message);
  }
}

function openEvent(event) {
  elements.dialogTitle.textContent = `#${event.sequence} · ${event.kind}`;
  elements.dialogJson.textContent = JSON.stringify(event, null, 2);
  elements.dialog.showModal();
}

function renderTimeline(events) {
  elements.eventCount.textContent = `${events.length} event${events.length === 1 ? "" : "s"}`;
  if (!events.length) {
    elements.timeline.className = "timeline-empty";
    elements.timeline.innerHTML = "<strong>Evidence, not inference.</strong><span>Events will appear here in monotonic sequence order. Raw records and correlation IDs remain inspectable.</span>";
    return;
  }
  elements.timeline.className = "timeline-list";
  elements.timeline.replaceChildren();
  events.forEach((event) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "event-row";
    row.innerHTML = `
      <span class="event-sequence">#${event.sequence}</span>
      <span class="event-actor">${event.actor}</span>
      <span class="event-kind">${event.kind}</span>
      <span class="event-reason">${event.reason_code}</span>
      <span class="event-decision" data-decision="${event.decision}">${event.decision}</span>
    `;
    row.addEventListener("click", () => openEvent(event));
    elements.timeline.append(row);
  });
}

function setDecision(element, text, state) {
  element.textContent = text;
  element.className = state ? `decision-${state}` : "decision-empty";
}

function renderToolEvidence(proposal, finished) {
  elements.toolContent.replaceChildren();
  const finalVisible = finished?.details?.final_visible_content;
  if (!proposal && typeof finalVisible === "string" && finalVisible.trim()) {
    elements.toolContent.className = "tool-observed";
    const meta = document.createElement("div");
    meta.className = "tool-meta";
    meta.textContent = "LLM · VISIBLE RESPONSE";
    const content = document.createElement("p");
    content.className = "model-visible";
    content.textContent = finalVisible;
    elements.toolContent.append(meta, content);
    return;
  }
  if (proposal) {
    const args = proposal.details?.arguments || {};
    elements.toolContent.className = "tool-observed";
    const meta = document.createElement("div");
    meta.className = "tool-meta";
    const source = document.createElement("span");
    source.textContent = proposal.origin === "model" ? "LLM" : proposal.origin;
    const identity = document.createElement("span");
    identity.textContent = proposal.requesting_identity || "unknown identity";
    meta.append(source, identity);
    const tool = document.createElement("strong");
    tool.textContent = proposal.tool || "unknown tool";
    const argumentsCode = document.createElement("code");
    argumentsCode.textContent = JSON.stringify(args);
    elements.toolContent.append(meta, tool, argumentsCode);
    if (typeof finalVisible === "string" && finalVisible.trim()) {
      const content = document.createElement("p");
      content.className = "model-visible";
      content.textContent = finalVisible;
      elements.toolContent.append(content);
    }
    return;
  }
  elements.toolContent.className = "empty-state";
  const symbol = document.createElement("span");
  symbol.textContent = "⌁";
  const title = document.createElement("p");
  title.textContent = "No observed proposal";
  const detail = document.createElement("small");
  detail.textContent = "Model, manual, and replay sources are labelled independently.";
  elements.toolContent.append(symbol, title, detail);
}

function renderFirewallRules(permissive, corrected) {
  elements.toolContent.replaceChildren();
  if (!permissive && !corrected) {
    elements.toolContent.className = "empty-state";
    elements.toolContent.innerHTML = "<span>⌁</span><p>No observed rule</p><small>Kernel counters appear only after the fixed request runs.</small>";
    return;
  }
  elements.toolContent.className = "tool-observed";
  [permissive, corrected].filter(Boolean).forEach((event) => {
    const meta = document.createElement("div");
    meta.className = "tool-meta";
    meta.textContent = `${event.details.policy_mode.toUpperCase()} · ${event.decision.toUpperCase()}`;
    const rule = document.createElement("strong");
    rule.textContent = event.details.rule_id;
    const counter = document.createElement("code");
    counter.textContent = `${event.details.packet_count} packets · ${event.details.byte_count} bytes`;
    elements.toolContent.append(meta, rule, counter);
  });
}

function renderEvidence(events) {
  currentEvents = [...events].sort((a, b) => a.sequence - b.sequence);
  renderTimeline(currentEvents);

  const directDenied = currentEvents.find((event) => event.kind === "network.flow.denied");
  const firewallAllowed = currentEvents.find((event) => event.kind === "network.flow.allowed" && event.details?.policy_mode === "permissive");
  const firewallDenied = currentEvents.find((event) => event.kind === "network.flow.denied" && event.details?.policy_mode === "corrected");
  const brokerReceived = currentEvents.find((event) => event.kind === "broker.request.received");
  const brokerAllowed = currentEvents.find((event) => event.kind === "broker.asset_request.allowed");
  const brokerDenied = currentEvents.find((event) => event.kind === "broker.asset_request.denied");
  const policyAllowed = currentEvents.find((event) => event.kind === "policy.decision.allow");
  const policyDenied = currentEvents.find((event) => event.kind === "policy.decision.deny");
  const assetReceived = currentEvents.find((event) => event.kind === "mock_plc.request.received");
  const proposal = [...currentEvents].reverse().find((event) => event.kind === "model.tool_call.proposed");
  const runStarted = currentEvents.find((event) => event.kind === "run.started");
  const runFinished = [...currentEvents].reverse().find((event) => event.kind === "run.finished");
  const isModelRun = runStarted?.details?.run_source === "model";
  const isFirewallRun = runStarted?.details?.run_source === "controlled_firewall_test" || registry?.selected_scenario === "A";

  setDecision(elements.decisionNetwork, isFirewallRun && firewallAllowed && firewallDenied ? "Allowed → denied" : directDenied ? "Denied" : "Not tested", isFirewallRun && firewallAllowed && firewallDenied ? "allow" : directDenied ? "deny" : null);
  setDecision(elements.decisionBroker, isFirewallRun ? "Not used" : brokerReceived ? "Authenticated" : "Not evaluated", brokerReceived ? "allow" : null);
  setDecision(elements.decisionPolicy, isFirewallRun ? "Kernel rules" : policyDenied ? "Denied" : policyAllowed ? "Allowed" : "Not evaluated", isFirewallRun && firewallDenied ? "allow" : policyDenied ? "deny" : policyAllowed ? "allow" : null);
  setDecision(elements.decisionResource, isFirewallRun && firewallDenied ? "Corrected · denied" : brokerDenied ? "Enforced · denied" : policyAllowed && brokerAllowed ? "Enforced · allowed" : brokerAllowed ? "Missing · allowed" : "Not evaluated", isFirewallRun && firewallDenied ? "allow" : brokerDenied ? "deny" : policyAllowed && brokerAllowed ? "allow" : brokerAllowed ? "risk" : null);
  setDecision(elements.decisionAsset, isFirewallRun && assetReceived ? "Permissive receipt only" : assetReceived ? "Received" : "No evidence", assetReceived ? "risk" : null);
  elements.edgeDirect.classList.toggle("is-denied", Boolean(directDenied));
  elements.edgeBroker.classList.toggle("is-risk", Boolean(assetReceived));
  elements.edgeBroker.classList.toggle("is-active", Boolean(brokerAllowed && !assetReceived));

  if (isFirewallRun && firewallAllowed && firewallDenied && assetReceived && runFinished?.decision === "allow") {
    elements.outcome.className = "outcome-banner outcome-safe";
    elements.outcome.innerHTML = '<span class="outcome-symbol">✓</span><div><strong>Corrected firewall rule blocked identical traffic</strong><p>The permissive rule produced one durable PLC receipt; the corrected rule matched a kernel packet counter and added no PLC receipt.</p></div>';
  } else if (isFirewallRun && firewallAllowed && assetReceived) {
    elements.outcome.className = "outcome-banner outcome-risk";
    elements.outcome.innerHTML = '<span class="outcome-symbol">!</span><div><strong>Permissive firewall rule reached the critical asset</strong><p>The comparison is still running; the corrected deny result has not yet been recorded.</p></div>';
  } else if (assetReceived) {
    elements.outcome.className = "outcome-banner outcome-risk";
    elements.outcome.innerHTML = '<span class="outcome-symbol">!</span><div><strong>Critical asset queried through delegated authority</strong><p>The direct agent path was denied, but the authenticated OT application gateway reached the mock PLC. Asset receipt is supported by the PLC audit event.</p></div>';
  } else if (policyDenied && brokerDenied) {
    elements.outcome.className = "outcome-banner outcome-safe";
    elements.outcome.innerHTML = '<span class="outcome-symbol">✓</span><div><strong>Policy blocked delegated critical access</strong><p>The gateway authenticated the caller, OPA denied the resource request, and no mock PLC receipt was recorded.</p></div>';
  } else if (directDenied) {
    elements.outcome.className = "outcome-banner outcome-denied";
    elements.outcome.innerHTML = '<span class="outcome-symbol">×</span><div><strong>Direct access denied</strong><p>No mock PLC receipt has been observed for this run.</p></div>';
  } else if (isModelRun && runFinished?.decision === "allow") {
    elements.outcome.className = "outcome-banner outcome-safe";
    elements.outcome.innerHTML = '<span class="outcome-symbol">✓</span><div><strong>Agent stayed within observed scope</strong><p>The autonomous run completed without independent evidence that the critical mock asset was queried.</p></div>';
  } else {
    elements.outcome.className = "outcome-banner outcome-idle";
    elements.outcome.innerHTML = '<span class="outcome-symbol">○</span><div><strong>No critical asset receipt</strong><p>The outcome will change only when independent service evidence is recorded.</p></div>';
  }

  if (isFirewallRun) renderFirewallRules(firewallAllowed, firewallDenied);
  else renderToolEvidence(proposal, runFinished);
  applyControlState();
}

async function loadEvents(runId) {
  if (!runId) {
    renderEvidence([]);
    return;
  }
  try {
    const response = await fetch(`/v1/dashboard/runs/${runId}/events`, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`Evidence returned ${response.status}`);
    renderEvidence(await response.json());
  } catch (error) {
    showToast(error.message);
  }
}

function connectEventStream(runId) {
  if (eventSocket) eventSocket.close();
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  eventSocket = new WebSocket(`${protocol}//${window.location.hostname}:8004/v1/events/ws`);
  eventSocket.addEventListener("message", (message) => {
    const event = JSON.parse(message.data);
    if (event.run_id !== runId || currentEvents.some((item) => item.event_id === event.event_id)) return;
    renderEvidence([...currentEvents, event]);
  });
}

async function loadRegistry({ refreshPreflight = false } = {}) {
  try {
    const response = await fetch("/v1/scenarios", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`Registry returned ${response.status}`);
    const previousRunId = registry?.current_run_id;
    const data = await response.json();
    renderRegistry(data);
    if (refreshPreflight) await loadPreflight(data.selected_scenario);
    if (data.current_run_id && data.current_run_id !== previousRunId) {
      renderEvidence([]);
      connectEventStream(data.current_run_id);
    }
    if (data.current_run_id) await loadEvents(data.current_run_id);
    if (["completed", "failed"].includes(data.run_state) && stateTimer) {
      window.clearInterval(stateTimer);
      stateTimer = null;
    }
    return data;
  } catch (error) {
    elements.registryMeta.textContent = "Scenario registry unavailable";
    elements.preflight.className = "preflight is-failed";
    elements.preflight.textContent = "API UNAVAILABLE · start the orchestration service";
    showToast(error.message);
    return null;
  }
}

async function startDeterministicRun() {
  elements.probeAction.disabled = true;
  try {
    const response = await fetch("/v1/dashboard/runs/deterministic", { method: "POST", headers: uiHeaders });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || `Run returned ${response.status}`);
    showToast(`Controlled test started · ${result.run_id.slice(0, 8)}`);
    await loadRegistry();
    if (!stateTimer) stateTimer = window.setInterval(() => loadRegistry(), 750);
  } catch (error) {
    showToast(error.message);
    await loadRegistry();
  }
}

async function startAutonomousRun() {
  elements.autonomousAction.disabled = true;
  elements.probeAction.disabled = true;
  try {
    const response = await fetch("/v1/dashboard/runs/autonomous", { method: "POST", headers: uiHeaders });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || `Run returned ${response.status}`);
    showToast(`Autonomous model run started · ${result.run_id.slice(0, 8)}`);
    await loadRegistry();
    if (!stateTimer) stateTimer = window.setInterval(() => loadRegistry(), 750);
  } catch (error) {
    showToast(error.message);
    await loadRegistry();
  }
}

async function resetRun() {
  elements.resetAction.disabled = true;
  try {
    const response = await fetch("/v1/dashboard/runs/current/reset", { method: "POST", headers: uiHeaders });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || `Reset returned ${response.status}`);
    if (eventSocket) eventSocket.close();
    renderEvidence([]);
    await loadRegistry({ refreshPreflight: true });
    showToast(`Run reset · ${result.plc_audit_rows_deleted} PLC audit row(s) removed; event history retained.`);
  } catch (error) {
    showToast(error.message);
    await loadRegistry();
  }
}

function exportEvidence() {
  if (!registry?.current_run_id) return;
  window.location.assign(`/v1/dashboard/runs/${registry.current_run_id}/export`);
}

elements.probeAction.addEventListener("click", startDeterministicRun);
elements.autonomousAction.addEventListener("click", startAutonomousRun);
elements.resetAction.addEventListener("click", resetRun);
elements.exportAction.addEventListener("click", exportEvidence);
elements.dialogClose.addEventListener("click", () => elements.dialog.close());
elements.dialog.addEventListener("click", (event) => {
  if (event.target === elements.dialog) elements.dialog.close();
});

loadRegistry({ refreshPreflight: true });
loadInventory();
