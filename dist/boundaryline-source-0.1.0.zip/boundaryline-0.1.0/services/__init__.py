"""BoundaryLine synthetic services."""
