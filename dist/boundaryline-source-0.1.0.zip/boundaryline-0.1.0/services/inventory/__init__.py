"""Synthetic asset inventory service."""
